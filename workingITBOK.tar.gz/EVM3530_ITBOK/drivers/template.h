/* xxxxxxx.h - */

/* Copyright Mistral software Pvt. Ltd. */

/*
modificiation history
---------------------
01a,06apr07,msr Created
*/

/*
DESCRIPTION
*/


#ifndef __MS_DIAG_XXXXXX__
#define __MS_DIAG_xxxxxx__

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif

#endif
