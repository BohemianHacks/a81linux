#!/bin/sh
rm libitbok.a
rm drivers/.depend drivers/src/*.o drivers/*.a
rm diagnostics/.depend diagnostics/src/*.o diagnostics/*.a
rm common/src/*.o
rm device/src/*.o
